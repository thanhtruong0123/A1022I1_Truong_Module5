export function StudentList() {
    return (
        <h1>Student List</h1>
    )
}
